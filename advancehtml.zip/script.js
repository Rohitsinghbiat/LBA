 let users = [];
let loggedInUser = null;

function signup() {
  let name = document.getElementById("name").value;
  let address = document.getElementById("address").value;
  let number = document.getElementById("number").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;

  if (!name || !address || !number || !email || !password) {
    document.getElementById("message").innerHTML = "Please fill all fields.";
    return;
  }

  let user = {
    name: name,
    address: address,
    number: number,
    email: email,
    password: password
  };

  users.push(user);

  document.getElementById("signup").style.display = "none";
  document.getElementById("loading").style.display = "block";

  setTimeout(() => {
    document.getElementById("loading").style.display = "none";
    document.getElementById("login").style.display = "block";
  }, 5000);
}

function login() {
  let loginNumber = document.getElementById("loginNumber").value;
  let loginPassword = document.getElementById("loginPassword").value;

  let foundUser = users.find(user => user.number === loginNumber && user.password === loginPassword);

  if (foundUser) {
    loggedInUser = foundUser;
    document.getElementById("loading").style.display = "block";
    setTimeout(() => {
      window.location.href = "/lba.html"; // Redirect to welcome page after 5 seconds
    }, 5000);
  } else {
    let foundNumber = users.find(user => user.number === loginNumber);
    if (foundNumber) {
      document.getElementById("message").innerHTML = "Invalid password.";
    } else {
      document.getElementById("message").innerHTML = "Invalid number.";
    }
  }
}
